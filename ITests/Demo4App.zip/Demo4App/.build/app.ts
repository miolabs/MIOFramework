


class Movie extends NSManagedObject{
initEntityNSEntityDescriptionInsertIntoOptional(entity, context, $info?){
let _this = this;

super.initEntityNSEntityDescriptionInsertIntoOptional(entity, context);
return ;
}

static fetchRequest($info?){
let _this = this;

return _create(NSFetchRequest, 'initEntityNameString', "Movie", {});
}

isFavorite$internal
isFavorite$get() { return this.isFavorite$internal }
get isFavorite() { return this.isFavorite$get() }
isFavorite$set($newValue) {
let $oldValue = this.isFavorite$internal
this.isFavorite$internal = $newValue
}
set isFavorite($newValue) { this.isFavorite$set($newValue) }
;





_name$internal
_name$get() { return this._name$internal }
get _name() { return this._name$get() }
_name$set($newValue) {
let $oldValue = this._name$internal
this._name$internal = $newValue
}
set _name($newValue) { this._name$set($newValue) }
;




init$vars() {let _this = this;

if(super.init$vars)super.init$vars()
}
}





class TableViewController extends UITableViewController implements NSFetchedResultsControllerDelegate{
viewDidLoad($info?){
let _this = this;

super.viewDidLoad( {});
}
numberOfSectionsIn(tableView, $info?){
let _this = this;

return (Optional.$notEqual(_this.fetchedResultsController.sections, _injectIntoOptional(null)) ? _this.fetchedResultsController.sections[0].count : 0);
}
tableViewNumberOfRowsInSection(tableView, section, $info?){
let _this = this;


const sectionInfo = _injectIntoOptional(((_.tmp0 = _this.fetchedResultsController.sections).rawValue === 'some') ? (_.tmp0[0].subscript$get(section)) : null);

;

;
return sectionInfo[0].numberOfObjects;
}
tableViewCellForRowAt(tableView, indexPath, $info?){
let _this = this;


const cell = tableView.dequeueReusableCellWithIdentifierFor("Cell", indexPath);

;

;
_this.configureCellAt(cell, indexPath);
return cell;
}
configureCellAt(cell, indexPath, $info?){
let _this = this;


const movie = _this.fetchedResultsController.objectAt(indexPath);

;

;
_injectIntoOptional(((_.tmp1 = cell.textLabel).rawValue === 'some') ? (_.tmp1[0].text = movie._name) : null);
}

fetchedResultsController$internal
fetchedResultsController$get() { return this.fetchedResultsController$internal }
get fetchedResultsController() { return this.fetchedResultsController$get() }
fetchedResultsController$set($newValue) {
let $oldValue = this.fetchedResultsController$internal
this.fetchedResultsController$internal = $newValue
}
set fetchedResultsController($newValue) { this.fetchedResultsController$set($newValue) }
;



$__lazy_storage_$_fetchedResultsController$internal
$__lazy_storage_$_fetchedResultsController$get() { return this.$__lazy_storage_$_fetchedResultsController$internal }
get $__lazy_storage_$_fetchedResultsController() { return this.$__lazy_storage_$_fetchedResultsController$get() }
$__lazy_storage_$_fetchedResultsController$set($newValue) {
let $oldValue = this.$__lazy_storage_$_fetchedResultsController$internal
this.$__lazy_storage_$_fetchedResultsController$internal = $newValue
}
set $__lazy_storage_$_fetchedResultsController($newValue) { this.$__lazy_storage_$_fetchedResultsController$set($newValue) }
;





controllerWillChangeContent(controller, $info?){
let _this = this;

_this.tableView[0].beginUpdates( {});
}
controllerDidChangeAtForNewIndexPath(controller, anObject, indexPath, type, newIndexPath, $info?){
let _this = this;

const $match = type
if((($match.rawValue == NSFetchedResultsChangeType.insert.rawValue))) {
const $ifLet0, indexPath_1

if((($ifLet0 = newIndexPath)||true) && $ifLet0.rawValue == 'some' && ((indexPath_1 = $ifLet0[0])||true)) {

_this.tableView[0].insertRowsAtWith(_create(Array, 'initArrayLiteralArray', [indexPath_1], {}), UITableView.RowAnimation.fade);
};
;
}
else if((($match.rawValue == NSFetchedResultsChangeType.delete.rawValue))) {
const $ifLet2, indexPath_3

if((($ifLet2 = indexPath)||true) && $ifLet2.rawValue == 'some' && ((indexPath_3 = $ifLet2[0])||true)) {

_this.tableView[0].deleteRowsAtWith(_create(Array, 'initArrayLiteralArray', [indexPath_3], {}), UITableView.RowAnimation.fade);
};
;
}
else if((($match.rawValue == NSFetchedResultsChangeType.update.rawValue))) {
const $ifLet4, indexPath_5
const $ifLet6, cell_7

if((($ifLet4 = indexPath)||true) && $ifLet4.rawValue == 'some' && ((indexPath_5 = $ifLet4[0])||true) && (($ifLet6 = _this.tableView[0].cellForRowAt(indexPath_5))||true) && $ifLet6.rawValue == 'some' && ((cell_7 = $ifLet6[0])||true)) {

_this.configureCellAt(cell_7, indexPath_5);
};
;
}
else if((($match.rawValue == NSFetchedResultsChangeType.move.rawValue))) {
const $ifLet8, indexPath_9

if((($ifLet8 = indexPath)||true) && $ifLet8.rawValue == 'some' && ((indexPath_9 = $ifLet8[0])||true)) {

_this.tableView[0].deleteRowsAtWith(_create(Array, 'initArrayLiteralArray', [indexPath_9], {}), UITableView.RowAnimation.fade);
};
const $ifLet10, newIndexPath_11

if((($ifLet10 = newIndexPath)||true) && $ifLet10.rawValue == 'some' && ((newIndexPath_11 = $ifLet10[0])||true)) {

_this.tableView[0].insertRowsAtWith(_create(Array, 'initArrayLiteralArray', [newIndexPath_11], {}), UITableView.RowAnimation.fade);
};
;
}
else if(((true))) {
NSLog("Unknown", _create(Array, 'initArrayLiteralArray', [], {}));
};
}
controllerDidChangeContent(controller, $info?){
let _this = this;

_this.tableView[0].endUpdates( {});
}
addButtonClickedSender(sender, $info?){
let _this = this;


const avc = _create(UIAlertController, 'initTitleOptionalMessageOptionalPreferredStyleUIAlertControllerStyle', _injectIntoOptional("Alert"), _injectIntoOptional("Add a new movie"), UIAlertController.Style.alert, {});

;

;
avc.addTextFieldConfigurationHandler(_injectIntoOptional(((textField, $info?) => textField.placeholder = _injectIntoOptional("Name"))));
avc.addAction(_create(UIAlertAction, 'initTitleOptionalStyleUIAlertActionStyleHandlerOptional', _injectIntoOptional("OK"), UIAlertAction.Style._default, _injectIntoOptional(((action, $info?) => { 

const ad = UIApplication.shared.delegate[0];

;

;

const movie = _injectIntoOptional(NSEntityDescription.insertNewObjectForEntityNameInto("Movie", ad.persistentContainer.viewContext));

;

;
_injectIntoOptional(((_.tmp3 = movie).rawValue === 'some') ? (_.tmp3[0]._name = (((_.tmp2 = avc.textFields).rawValue === 'some') ? (_.tmp2[0].subscript$get(0).text) : Optional.none)) : null);
ad.saveContext( {}); })), {}));
avc.addAction(_create(UIAlertAction, 'initTitleOptionalStyleUIAlertActionStyleHandlerOptional', _injectIntoOptional("Cancel"), UIAlertAction.Style.cancel, _injectIntoOptional(null), {}));
_this.presentAnimatedCompletion(avc, true, _injectIntoOptional(null));
}
initStyleUITableViewStyle(style, $info?){
let _this = this;

super.initStyleUITableViewStyle(style);
return ;
}
initNibNameOptionalBundleOptional(nibNameOrNil, nibBundleOrNil, $info?){
let _this = this;

super.initNibNameOptionalBundleOptional(nibNameOrNil, nibBundleOrNil);
return ;
}
initCoderNSCoder(aDecoder, $info?){
let _this = this;

super.initCoderNSCoder(aDecoder);
return ;
}
static readonly initCoderNSCoder$failable = true

init$vars() {let _this = this;

if(super.init$vars)super.init$vars()
this.fetchedResultsController$internal = (($info?) => { 

const appDelegate = UIApplication.shared.delegate[0];

;

;

const managedContext = appDelegate.persistentContainer.viewContext;

;

;

const fetchRequest = _create(NSFetchRequest, 'initEntityNameString', "Movie", {});

;

;

const sortDescriptor = _create(NSSortDescriptor, 'initKeyOptionalAscendingBool', _injectIntoOptional("name"), false, {});

;

;
fetchRequest.sortDescriptors = _injectIntoOptional(_create(Array, 'initArrayLiteralArray', [sortDescriptor], {}));

const fetchedResultsController = _create(NSFetchedResultsController, 'initFetchRequestNSFetchRequestManagedObjectContextNSManagedObjectContextSectionNameKeyPathOptionalCacheNameOptional', fetchRequest, managedContext, _injectIntoOptional(null), _injectIntoOptional(null), {});

;

;
fetchedResultsController.delegate = _injectIntoOptional(_this);
try {
fetchedResultsController.performFetch( {});
} catch(error) {
if((true)) {

const fetchError = error;

;

;
printSeparatorTerminator(_create(Array, 'initArrayLiteralArray', ["Unable to Perform Fetch Request"], {}),   null,   null);
printSeparatorTerminator(_create(Array, 'initArrayLiteralArray', [(("") + (fetchError.description) + (", ") + (fetchError.localizedDescription) + (""))], {}),   null,   null);
}
else throw error
};
return fetchedResultsController; })( {})
this.$__lazy_storage_$_fetchedResultsController$internal = _injectIntoOptional(null)
}
}
if(typeof NSFetchedResultsControllerDelegate$implementation != 'undefined') _mixin(TableViewController, NSFetchedResultsControllerDelegate$implementation, false)

class ViewController extends UIViewController{
viewDidLoad($info?){
let _this = this;

super.viewDidLoad( {});
}
initNibNameOptionalBundleOptional(nibNameOrNil, nibBundleOrNil, $info?){
let _this = this;

super.initNibNameOptionalBundleOptional(nibNameOrNil, nibBundleOrNil);
return ;
}
initCoderNSCoder(aDecoder, $info?){
let _this = this;

super.initCoderNSCoder(aDecoder);
return ;
}
static readonly initCoderNSCoder$failable = true

init$vars() {let _this = this;

if(super.init$vars)super.init$vars()
}
}


class AppDelegate extends UIResponder implements UIApplicationDelegate{

window$internal
window$get() { return this.window$internal }
get window() { return this.window$get() }
window$set($newValue) {
let $oldValue = this.window$internal
this.window$internal = $newValue
}
set window($newValue) { this.window$set($newValue) }
;





applicationDidFinishLaunchingWithOptions(application, launchOptions, $info?){
let _this = this;

return true;
}
applicationWillResignActive(application, $info?){
let _this = this;

}
applicationDidEnterBackground(application, $info?){
let _this = this;

}
applicationWillEnterForeground(application, $info?){
let _this = this;

}
applicationDidBecomeActive(application, $info?){
let _this = this;

}
applicationWillTerminate(application, $info?){
let _this = this;

_this.saveContext( {});
}

persistentContainer$internal
persistentContainer$get() { return this.persistentContainer$internal }
get persistentContainer() { return this.persistentContainer$get() }
persistentContainer$set($newValue) {
let $oldValue = this.persistentContainer$internal
this.persistentContainer$internal = $newValue
}
set persistentContainer($newValue) { this.persistentContainer$set($newValue) }
;



$__lazy_storage_$_persistentContainer$internal
$__lazy_storage_$_persistentContainer$get() { return this.$__lazy_storage_$_persistentContainer$internal }
get $__lazy_storage_$_persistentContainer() { return this.$__lazy_storage_$_persistentContainer$get() }
$__lazy_storage_$_persistentContainer$set($newValue) {
let $oldValue = this.$__lazy_storage_$_persistentContainer$internal
this.$__lazy_storage_$_persistentContainer$internal = $newValue
}
set $__lazy_storage_$_persistentContainer($newValue) { this.$__lazy_storage_$_persistentContainer$set($newValue) }
;





saveContext($info?){
let _this = this;


const context = _this.persistentContainer.viewContext;

;

;

if((context.hasChanges)) {

try {
context.save( {});
} catch(error) {
if((true)) {

const nserror = error;

;

;
fatalErrorFileLine(() => (("Unresolved error ") + (nserror.description) + (", ") + (nserror.userInfo.description) + ("")), null, null);
}
else throw error
};
};
}
init($info?){
let _this = this;

super.init( {});
return ;
}

init$vars() {let _this = this;

if(super.init$vars)super.init$vars()
this.window$internal = _injectIntoOptional(null)
this.persistentContainer$internal = (($info?) => { 

const container = _create(NSPersistentContainer, 'initNameString', "Demo4App", {});

;

;
container.loadPersistentStoresCompletionHandler(((storeDescription, error, $info?) => { 
const $ifLet12, error_13

if((($ifLet12 = _injectIntoOptional(((_.tmp4 = error).rawValue === 'some') ? (_.tmp4[0]) : null))||true) && $ifLet12.rawValue == 'some' && ((error_13 = $ifLet12[0])||true)) {

fatalErrorFileLine(() => (("Unresolved error ") + (error_13.description) + (", ") + (error_13.userInfo.description) + ("")), null, null);
}; }));
return container; })( {})
this.$__lazy_storage_$_persistentContainer$internal = _injectIntoOptional(null)
}
}
if(typeof UIApplicationDelegate$implementation != 'undefined') _mixin(AppDelegate, UIApplicationDelegate$implementation, false)