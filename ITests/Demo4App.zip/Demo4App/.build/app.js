var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Movie = /** @class */ (function (_super) {
    __extends(Movie, _super);
    function Movie() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Movie.prototype.initEntityNSEntityDescriptionInsertIntoOptional = function (entity, context, $info) {
        var _this = this;
        _super.prototype.initEntityNSEntityDescriptionInsertIntoOptional.call(this, entity, context);
        return;
    };
    Movie.fetchRequest = function ($info) {
        var _this = this;
        return _create(NSFetchRequest, 'initEntityNameString', "Movie", {});
    };
    Movie.prototype.isFavorite$get = function () { return this.isFavorite$internal; };
    Object.defineProperty(Movie.prototype, "isFavorite", {
        get: function () { return this.isFavorite$get(); },
        set: function ($newValue) { this.isFavorite$set($newValue); },
        enumerable: true,
        configurable: true
    });
    Movie.prototype.isFavorite$set = function ($newValue) {
        var $oldValue = this.isFavorite$internal;
        this.isFavorite$internal = $newValue;
    };
    ;
    Movie.prototype._name$get = function () { return this._name$internal; };
    Object.defineProperty(Movie.prototype, "_name", {
        get: function () { return this._name$get(); },
        set: function ($newValue) { this._name$set($newValue); },
        enumerable: true,
        configurable: true
    });
    Movie.prototype._name$set = function ($newValue) {
        var $oldValue = this._name$internal;
        this._name$internal = $newValue;
    };
    ;
    Movie.prototype.init$vars = function () {
        var _this = this;
        if (_super.prototype.init$vars)
            _super.prototype.init$vars.call(this);
    };
    return Movie;
}(NSManagedObject));
var TableViewController = /** @class */ (function (_super) {
    __extends(TableViewController, _super);
    function TableViewController() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    TableViewController.prototype.viewDidLoad = function ($info) {
        var _this = this;
        _super.prototype.viewDidLoad.call(this, {});
    };
    TableViewController.prototype.numberOfSectionsIn = function (tableView, $info) {
        var _this = this;
        return (Optional.$notEqual(_this.fetchedResultsController.sections, _injectIntoOptional(null)) ? _this.fetchedResultsController.sections[0].count : 0);
    };
    TableViewController.prototype.tableViewNumberOfRowsInSection = function (tableView, section, $info) {
        var _this = this;
        var sectionInfo = _injectIntoOptional(((_.tmp0 = _this.fetchedResultsController.sections).rawValue === 'some') ? (_.tmp0[0].subscript$get(section)) : null);
        ;
        ;
        return sectionInfo[0].numberOfObjects;
    };
    TableViewController.prototype.tableViewCellForRowAt = function (tableView, indexPath, $info) {
        var _this = this;
        var cell = tableView.dequeueReusableCellWithIdentifierFor("Cell", indexPath);
        ;
        ;
        _this.configureCellAt(cell, indexPath);
        return cell;
    };
    TableViewController.prototype.configureCellAt = function (cell, indexPath, $info) {
        var _this = this;
        var movie = _this.fetchedResultsController.objectAt(indexPath);
        ;
        ;
        _injectIntoOptional(((_.tmp1 = cell.textLabel).rawValue === 'some') ? (_.tmp1[0].text = movie._name) : null);
    };
    TableViewController.prototype.fetchedResultsController$get = function () { return this.fetchedResultsController$internal; };
    Object.defineProperty(TableViewController.prototype, "fetchedResultsController", {
        get: function () { return this.fetchedResultsController$get(); },
        set: function ($newValue) { this.fetchedResultsController$set($newValue); },
        enumerable: true,
        configurable: true
    });
    TableViewController.prototype.fetchedResultsController$set = function ($newValue) {
        var $oldValue = this.fetchedResultsController$internal;
        this.fetchedResultsController$internal = $newValue;
    };
    ;
    TableViewController.prototype.$__lazy_storage_$_fetchedResultsController$get = function () { return this.$__lazy_storage_$_fetchedResultsController$internal; };
    Object.defineProperty(TableViewController.prototype, "$__lazy_storage_$_fetchedResultsController", {
        get: function () { return this.$__lazy_storage_$_fetchedResultsController$get(); },
        set: function ($newValue) { this.$__lazy_storage_$_fetchedResultsController$set($newValue); },
        enumerable: true,
        configurable: true
    });
    TableViewController.prototype.$__lazy_storage_$_fetchedResultsController$set = function ($newValue) {
        var $oldValue = this.$__lazy_storage_$_fetchedResultsController$internal;
        this.$__lazy_storage_$_fetchedResultsController$internal = $newValue;
    };
    ;
    TableViewController.prototype.controllerWillChangeContent = function (controller, $info) {
        var _this = this;
        _this.tableView[0].beginUpdates({});
    };
    TableViewController.prototype.controllerDidChangeAtForNewIndexPath = function (controller, anObject, indexPath, type, newIndexPath, $info) {
        var _this = this;
        var $match = type;
        if ((($match.rawValue == NSFetchedResultsChangeType.insert.rawValue))) {
            var $ifLet0, indexPath_1;
            if ((($ifLet0 = newIndexPath) || true) && $ifLet0.rawValue == 'some' && ((indexPath_1 = $ifLet0[0]) || true)) {
                _this.tableView[0].insertRowsAtWith(_create(Array, 'initArrayLiteralArray', [indexPath_1], {}), UITableView.RowAnimation.fade);
            }
            ;
            ;
        }
        else if ((($match.rawValue == NSFetchedResultsChangeType["delete"].rawValue))) {
            var $ifLet2, indexPath_3;
            if ((($ifLet2 = indexPath) || true) && $ifLet2.rawValue == 'some' && ((indexPath_3 = $ifLet2[0]) || true)) {
                _this.tableView[0].deleteRowsAtWith(_create(Array, 'initArrayLiteralArray', [indexPath_3], {}), UITableView.RowAnimation.fade);
            }
            ;
            ;
        }
        else if ((($match.rawValue == NSFetchedResultsChangeType.update.rawValue))) {
            var $ifLet4, indexPath_5;
            var $ifLet6, cell_7;
            if ((($ifLet4 = indexPath) || true) && $ifLet4.rawValue == 'some' && ((indexPath_5 = $ifLet4[0]) || true) && (($ifLet6 = _this.tableView[0].cellForRowAt(indexPath_5)) || true) && $ifLet6.rawValue == 'some' && ((cell_7 = $ifLet6[0]) || true)) {
                _this.configureCellAt(cell_7, indexPath_5);
            }
            ;
            ;
        }
        else if ((($match.rawValue == NSFetchedResultsChangeType.move.rawValue))) {
            var $ifLet8, indexPath_9;
            if ((($ifLet8 = indexPath) || true) && $ifLet8.rawValue == 'some' && ((indexPath_9 = $ifLet8[0]) || true)) {
                _this.tableView[0].deleteRowsAtWith(_create(Array, 'initArrayLiteralArray', [indexPath_9], {}), UITableView.RowAnimation.fade);
            }
            ;
            var $ifLet10, newIndexPath_11;
            if ((($ifLet10 = newIndexPath) || true) && $ifLet10.rawValue == 'some' && ((newIndexPath_11 = $ifLet10[0]) || true)) {
                _this.tableView[0].insertRowsAtWith(_create(Array, 'initArrayLiteralArray', [newIndexPath_11], {}), UITableView.RowAnimation.fade);
            }
            ;
            ;
        }
        else if (((true))) {
            NSLog("Unknown", _create(Array, 'initArrayLiteralArray', [], {}));
        }
        ;
    };
    TableViewController.prototype.controllerDidChangeContent = function (controller, $info) {
        var _this = this;
        _this.tableView[0].endUpdates({});
    };
    TableViewController.prototype.addButtonClickedSender = function (sender, $info) {
        var _this = this;
        var avc = _create(UIAlertController, 'initTitleOptionalMessageOptionalPreferredStyleUIAlertControllerStyle', _injectIntoOptional("Alert"), _injectIntoOptional("Add a new movie"), UIAlertController.Style.alert, {});
        ;
        ;
        avc.addTextFieldConfigurationHandler(_injectIntoOptional((function (textField, $info) { return textField.placeholder = _injectIntoOptional("Name"); })));
        avc.addAction(_create(UIAlertAction, 'initTitleOptionalStyleUIAlertActionStyleHandlerOptional', _injectIntoOptional("OK"), UIAlertAction.Style._default, _injectIntoOptional((function (action, $info) {
            var ad = UIApplication.shared.delegate[0];
            ;
            ;
            var movie = _injectIntoOptional(NSEntityDescription.insertNewObjectForEntityNameInto("Movie", ad.persistentContainer.viewContext));
            ;
            ;
            _injectIntoOptional(((_.tmp3 = movie).rawValue === 'some') ? (_.tmp3[0]._name = (((_.tmp2 = avc.textFields).rawValue === 'some') ? (_.tmp2[0].subscript$get(0).text) : Optional.none)) : null);
            ad.saveContext({});
        })), {}));
        avc.addAction(_create(UIAlertAction, 'initTitleOptionalStyleUIAlertActionStyleHandlerOptional', _injectIntoOptional("Cancel"), UIAlertAction.Style.cancel, _injectIntoOptional(null), {}));
        _this.presentAnimatedCompletion(avc, true, _injectIntoOptional(null));
    };
    TableViewController.prototype.initStyleUITableViewStyle = function (style, $info) {
        var _this = this;
        _super.prototype.initStyleUITableViewStyle.call(this, style);
        return;
    };
    TableViewController.prototype.initNibNameOptionalBundleOptional = function (nibNameOrNil, nibBundleOrNil, $info) {
        var _this = this;
        _super.prototype.initNibNameOptionalBundleOptional.call(this, nibNameOrNil, nibBundleOrNil);
        return;
    };
    TableViewController.prototype.initCoderNSCoder = function (aDecoder, $info) {
        var _this = this;
        _super.prototype.initCoderNSCoder.call(this, aDecoder);
        return;
    };
    TableViewController.prototype.init$vars = function () {
        var _this = this;
        if (_super.prototype.init$vars)
            _super.prototype.init$vars.call(this);
        this.fetchedResultsController$internal = (function ($info) {
            var appDelegate = UIApplication.shared.delegate[0];
            ;
            ;
            var managedContext = appDelegate.persistentContainer.viewContext;
            ;
            ;
            var fetchRequest = _create(NSFetchRequest, 'initEntityNameString', "Movie", {});
            ;
            ;
            var sortDescriptor = _create(NSSortDescriptor, 'initKeyOptionalAscendingBool', _injectIntoOptional("name"), false, {});
            ;
            ;
            fetchRequest.sortDescriptors = _injectIntoOptional(_create(Array, 'initArrayLiteralArray', [sortDescriptor], {}));
            var fetchedResultsController = _create(NSFetchedResultsController, 'initFetchRequestNSFetchRequestManagedObjectContextNSManagedObjectContextSectionNameKeyPathOptionalCacheNameOptional', fetchRequest, managedContext, _injectIntoOptional(null), _injectIntoOptional(null), {});
            ;
            ;
            fetchedResultsController.delegate = _injectIntoOptional(_this);
            try {
                fetchedResultsController.performFetch({});
            }
            catch (error) {
                if ((true)) {
                    var fetchError = error;
                    ;
                    ;
                    printSeparatorTerminator(_create(Array, 'initArrayLiteralArray', ["Unable to Perform Fetch Request"], {}), null, null);
                    printSeparatorTerminator(_create(Array, 'initArrayLiteralArray', [(("") + (fetchError.description) + (", ") + (fetchError.localizedDescription) + (""))], {}), null, null);
                }
                else
                    throw error;
            }
            ;
            return fetchedResultsController;
        })({});
        this.$__lazy_storage_$_fetchedResultsController$internal = _injectIntoOptional(null);
    };
    TableViewController.initCoderNSCoder$failable = true;
    return TableViewController;
}(UITableViewController));
if (typeof NSFetchedResultsControllerDelegate$implementation != 'undefined')
    _mixin(TableViewController, NSFetchedResultsControllerDelegate$implementation, false);
var ViewController = /** @class */ (function (_super) {
    __extends(ViewController, _super);
    function ViewController() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    ViewController.prototype.viewDidLoad = function ($info) {
        var _this = this;
        _super.prototype.viewDidLoad.call(this, {});
    };
    ViewController.prototype.initNibNameOptionalBundleOptional = function (nibNameOrNil, nibBundleOrNil, $info) {
        var _this = this;
        _super.prototype.initNibNameOptionalBundleOptional.call(this, nibNameOrNil, nibBundleOrNil);
        return;
    };
    ViewController.prototype.initCoderNSCoder = function (aDecoder, $info) {
        var _this = this;
        _super.prototype.initCoderNSCoder.call(this, aDecoder);
        return;
    };
    ViewController.prototype.init$vars = function () {
        var _this = this;
        if (_super.prototype.init$vars)
            _super.prototype.init$vars.call(this);
    };
    ViewController.initCoderNSCoder$failable = true;
    return ViewController;
}(UIViewController));
var AppDelegate = /** @class */ (function (_super) {
    __extends(AppDelegate, _super);
    function AppDelegate() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    AppDelegate.prototype.window$get = function () { return this.window$internal; };
    Object.defineProperty(AppDelegate.prototype, "window", {
        get: function () { return this.window$get(); },
        set: function ($newValue) { this.window$set($newValue); },
        enumerable: true,
        configurable: true
    });
    AppDelegate.prototype.window$set = function ($newValue) {
        var $oldValue = this.window$internal;
        this.window$internal = $newValue;
    };
    ;
    AppDelegate.prototype.applicationDidFinishLaunchingWithOptions = function (application, launchOptions, $info) {
        var _this = this;
        return true;
    };
    AppDelegate.prototype.applicationWillResignActive = function (application, $info) {
        var _this = this;
    };
    AppDelegate.prototype.applicationDidEnterBackground = function (application, $info) {
        var _this = this;
    };
    AppDelegate.prototype.applicationWillEnterForeground = function (application, $info) {
        var _this = this;
    };
    AppDelegate.prototype.applicationDidBecomeActive = function (application, $info) {
        var _this = this;
    };
    AppDelegate.prototype.applicationWillTerminate = function (application, $info) {
        var _this = this;
        _this.saveContext({});
    };
    AppDelegate.prototype.persistentContainer$get = function () { return this.persistentContainer$internal; };
    Object.defineProperty(AppDelegate.prototype, "persistentContainer", {
        get: function () { return this.persistentContainer$get(); },
        set: function ($newValue) { this.persistentContainer$set($newValue); },
        enumerable: true,
        configurable: true
    });
    AppDelegate.prototype.persistentContainer$set = function ($newValue) {
        var $oldValue = this.persistentContainer$internal;
        this.persistentContainer$internal = $newValue;
    };
    ;
    AppDelegate.prototype.$__lazy_storage_$_persistentContainer$get = function () { return this.$__lazy_storage_$_persistentContainer$internal; };
    Object.defineProperty(AppDelegate.prototype, "$__lazy_storage_$_persistentContainer", {
        get: function () { return this.$__lazy_storage_$_persistentContainer$get(); },
        set: function ($newValue) { this.$__lazy_storage_$_persistentContainer$set($newValue); },
        enumerable: true,
        configurable: true
    });
    AppDelegate.prototype.$__lazy_storage_$_persistentContainer$set = function ($newValue) {
        var $oldValue = this.$__lazy_storage_$_persistentContainer$internal;
        this.$__lazy_storage_$_persistentContainer$internal = $newValue;
    };
    ;
    AppDelegate.prototype.saveContext = function ($info) {
        var _this = this;
        var context = _this.persistentContainer.viewContext;
        ;
        ;
        if ((context.hasChanges)) {
            try {
                context.save({});
            }
            catch (error) {
                if ((true)) {
                    var nserror_1 = error;
                    ;
                    ;
                    fatalErrorFileLine(function () { return (("Unresolved error ") + (nserror_1.description) + (", ") + (nserror_1.userInfo.description) + ("")); }, null, null);
                }
                else
                    throw error;
            }
            ;
        }
        ;
    };
    AppDelegate.prototype.init = function ($info) {
        var _this = this;
        _super.prototype.init.call(this, {});
        return;
    };
    AppDelegate.prototype.init$vars = function () {
        var _this = this;
        if (_super.prototype.init$vars)
            _super.prototype.init$vars.call(this);
        this.window$internal = _injectIntoOptional(null);
        this.persistentContainer$internal = (function ($info) {
            var container = _create(NSPersistentContainer, 'initNameString', "Demo4App", {});
            ;
            ;
            container.loadPersistentStoresCompletionHandler((function (storeDescription, error, $info) {
                var $ifLet12, error_13;
                if ((($ifLet12 = _injectIntoOptional(((_.tmp4 = error).rawValue === 'some') ? (_.tmp4[0]) : null)) || true) && $ifLet12.rawValue == 'some' && ((error_13 = $ifLet12[0]) || true)) {
                    fatalErrorFileLine(function () { return (("Unresolved error ") + (error_13.description) + (", ") + (error_13.userInfo.description) + ("")); }, null, null);
                }
                ;
            }));
            return container;
        })({});
        this.$__lazy_storage_$_persistentContainer$internal = _injectIntoOptional(null);
    };
    return AppDelegate;
}(UIResponder));
if (typeof UIApplicationDelegate$implementation != 'undefined')
    _mixin(AppDelegate, UIApplicationDelegate$implementation, false);
