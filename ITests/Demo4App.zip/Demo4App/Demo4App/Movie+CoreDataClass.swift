//
//  Movie+CoreDataClass.swift
//  Demo4App
//
//  Created by Bubulkowa norka on 29/05/2019.
//  Copyright © 2019 Javier Segura Perez. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Movie)
public class Movie: NSManagedObject {

}
